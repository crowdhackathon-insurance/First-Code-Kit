//
//  StatementViewController.m
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import "StatementViewController.h"

@interface StatementViewController ()

@end

@implementation StatementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UINavigationBar *myBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
    UINavigationItem *navItem = [[UINavigationItem alloc] init];
    navItem.title = @"ΗΛΔΑ";
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<Back" style:UIBarButtonItemStylePlain target:self action:@selector(backPressed)];
    navItem.leftBarButtonItem = leftButton;
    
    myBar.items = @[ navItem ];
    
    [self.view addSubview:myBar];
    
    
    //background
    self.view.backgroundColor = [UIColor colorWithRed:141.0/255.0 green:198.0/255.0 blue:63.0/255.0 alpha:1];;
    
    _nameTextField.text = @"Επωνυμο";
    _surnameTextField.text = @"Επωνυμο";
    _addressTextField.text = @"Επωνυμο";
    _countryTextField.text = @"Επωνυμο";
    _brandTextField.text = @"Επωνυμο";
    _licenseTextField.text = @"Επωνυμο";
    _companyNameTextField.text = @"Επωνυμο";
    _companyLicenseTextField.text = @"Επωνυμο";
    _driverNameTextField.text = @"Επωνυμο";
    _surnameDriverTextField.text = @"Επωνυμο";
    _addressDriverTextField.text = @"Επωνυμο";
    _countryDriverTextField.text = @"Επωνυμο";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void) backPressed {
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"StatementSelectionViewController"];
    [self presentViewController:vc animated:YES completion:nil];
    
}

@end
