//
//  ViewController.m
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NSArray *_pickerData;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UINavigationBar *myBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
    UINavigationItem *navItem = [[UINavigationItem alloc] init];
    navItem.title = @"ΗΛΔΑ";
    
    myBar.items = @[ navItem ];
    
    [self.view addSubview:myBar];
    
    // Company name Data
    _pickerData = @[@"Anytime", @"AXA", @"Ethiniki", @"Alliance", @"AIG", @"Groupama"];
    
    // Connect data
    self.companyPicker.dataSource = self;
    self.companyPicker.delegate = self;
    
    //background
    self.view.backgroundColor = [UIColor colorWithRed:141.0/255.0 green:198.0/255.0 blue:63.0/255.0 alpha:1];;
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// The number of columns of data
- (long)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// The number of rows of data
- (long)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _pickerData.count;
}

// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _pickerData[row];
}


@end
