//
//  StatementViewController.h
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatementViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *surnameTextField;
@property (weak, nonatomic) IBOutlet UITextField *addressTextField;
@property (weak, nonatomic) IBOutlet UITextField *countryTextField;
@property (weak, nonatomic) IBOutlet UITextField *brandTextField;
@property (weak, nonatomic) IBOutlet UITextField *licenseTextField;
@property (weak, nonatomic) IBOutlet UITextField *companyNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *companyLicenseTextField;
@property (weak, nonatomic) IBOutlet UITextField *driverNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *surnameDriverTextField;
@property (weak, nonatomic) IBOutlet UITextField *addressDriverTextField;
@property (weak, nonatomic) IBOutlet UITextField *countryDriverTextField;
@property (weak, nonatomic) IBOutlet UIButton *imageButton;
@property (weak, nonatomic) IBOutlet UIButton *submitButton;


@end
