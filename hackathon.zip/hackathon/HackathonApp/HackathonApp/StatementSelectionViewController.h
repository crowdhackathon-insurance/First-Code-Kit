//
//  StatementSelectionViewController.h
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 02/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface StatementSelectionViewController : UIViewController <CLLocationManagerDelegate>

@property (weak, nonatomic) IBOutlet UIButton *sumbitButton;
@property (weak, nonatomic) IBOutlet UIButton *firstPersonDetailsButton;
@property (weak, nonatomic) IBOutlet UIButton *secondPersonDetailsButton;
@property (weak, nonatomic) IBOutlet UIButton *imagesDetailsButton;
@property (weak, nonatomic) IBOutlet UIButton *getLocationButton;


@end
