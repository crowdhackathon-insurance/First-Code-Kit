//
//  SignUpViewController.h
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *licenceTextfield;
@property (weak, nonatomic) IBOutlet UILabel *licenceLabel;
@property (weak, nonatomic) IBOutlet UIButton *signUpButton;

@end
