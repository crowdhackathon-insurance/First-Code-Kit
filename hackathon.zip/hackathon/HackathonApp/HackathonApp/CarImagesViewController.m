//
//  CarImagesViewController.m
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import "CarImagesViewController.h"

@interface CarImagesViewController ()

@end

@implementation CarImagesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //Add car image to view
    UIImage *image = [UIImage imageNamed:@"carKatopsi.png"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    imageView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:imageView];
    [imageView addConstraint:[NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:512]];
    [imageView addConstraint:[NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:1 constant:200]];
    imageView.layer.zPosition = -5;
    
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:imageView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
    [self.view addSubview:imageView];
    
    //Add navigation bar
    UINavigationBar *myBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
    UINavigationItem *navItem = [[UINavigationItem alloc] init];
    navItem.title = @"ΗΛΔΑ";
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc] initWithTitle:@"<Back" style:UIBarButtonItemStylePlain target:self action:@selector(backPressed)];
    navItem.leftBarButtonItem = leftButton;
    
    myBar.items = @[ navItem ];
    
    [self.view addSubview:myBar];
    
    //background
    self.view.backgroundColor = [UIColor colorWithRed:141.0/255.0 green:198.0/255.0 blue:63.0/255.0 alpha:1];;
    
    //set locationButtonBackground
    [_topLeftButton setBackgroundImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    [_midLeftButton setBackgroundImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    [_botLeftButton setBackgroundImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    [_topRightButton setBackgroundImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    [_midRightButton setBackgroundImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    [_botRightButton setBackgroundImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    
    
    
    
    
    
}

- (IBAction)cameraUpLeftButtonPressed:(id)sender {
    [self openCamera];
}
- (IBAction)cameraMidLeftButtonPressed:(id)sender {
    [self openCamera];
}
- (IBAction)cameraBotLeftButtonPressed:(id)sender {
    [self openCamera];
}
- (IBAction)cameraTopRightButtonPressed:(id)sender {
    [self openCamera];
}
- (IBAction)cameraMidRightButtonPressed:(id)sender {
    [self openCamera];
}
- (IBAction)cameraBotRightButtonPressed:(id)sender {
    [self openCamera];
    
}

-(void) openCamera {
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc]init];
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        imagePicker.allowsEditing = YES;
        
        [self presentModalViewController:imagePicker animated:YES];
    }else{
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Camera Unavailable"
                                                       message:@"Unable to find a camera on your device."
                                                      delegate:nil
                                             cancelButtonTitle:@"OK"
                                             otherButtonTitles:nil, nil];
        [alert show];
        alert = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void) backPressed {
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"StatementSelectionViewController"];
    [self presentViewController:vc animated:YES completion:nil];
    
}
- (IBAction)topLeftButtonPressed:(id)sender {

    [_topLeftButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_topLeftButton setBackgroundImage:[UIImage imageNamed:@"okCamera.png"] forState:UIControlStateNormal];

}
- (IBAction)midLeftButtonPressed:(id)sender {

    [_midLeftButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_midLeftButton setBackgroundImage:[UIImage imageNamed:@"okCamera.png"] forState:UIControlStateNormal];
}
- (IBAction)botLeftButtonPressed:(id)sender {

    [_botLeftButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_botLeftButton setBackgroundImage:[UIImage imageNamed:@"okCamera.png"] forState:UIControlStateNormal];
}
- (IBAction)botRightButtonPressed:(id)sender {
    [_topRightButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_topRightButton setBackgroundImage:[UIImage imageNamed:@"okCamera.png"] forState:UIControlStateNormal];
    
}
- (IBAction)midRightButtonPressed:(id)sender {
    [_midRightButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_midRightButton setBackgroundImage:[UIImage imageNamed:@"okCamera.png"] forState:UIControlStateNormal];
    
}
- (IBAction)topRightButtonPressed:(id)sender {
    [_botRightButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_botRightButton setBackgroundImage:[UIImage imageNamed:@"okCamera.png"] forState:UIControlStateNormal];
    
}





@end
