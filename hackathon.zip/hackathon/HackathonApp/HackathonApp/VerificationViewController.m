//
//  VerificationViewController.m
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import "VerificationViewController.h"

@interface VerificationViewController ()

@end

@implementation VerificationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTimer];
    //background
    self.view.backgroundColor = [UIColor colorWithRed:141.0/255.0 green:198.0/255.0 blue:63.0/255.0 alpha:1];;
    
    _wrongCodeLabel.hidden = true;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)verificationButtonSelected:(id)sender {
    NSLog(@"InButtonListener");
    NSLog(@"%@", _verificationTextfield.text);

    if([_verificationTextfield.text isEqualToString:@"3552"]){
        NSLog(@"true!");
        NSString * storyboardName = @"Main";
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
        UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"StatementSelectionViewController"];
        [self presentViewController:vc animated:YES completion:nil];
    }else{
        _wrongCodeLabel.hidden = false;
    }
}
-(void) setTimer {
    secondsCount = 90;
    timer = [NSTimer scheduledTimerWithTimeInterval:1
                                             target:self
                                           selector:@selector(runTimer)
                                           userInfo:nil
                                            repeats:YES];
}

-(void) runTimer {
    secondsCount = secondsCount - 1;
    int minutes = secondsCount / 60;
    int seconds = secondsCount - (minutes * 60);
    
    NSString *timerOutpout = [NSString stringWithFormat:@"%2d:%.2d",minutes,seconds];
    countDownLabel.text = timerOutpout;
    
    if(secondsCount == 0){
        [timer invalidate];
        timer = nil;
        [self failToValidate];
        
    }
    
    
}

-(void) failToValidate {
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"FailToValidateViewController"];
    [self presentViewController:vc animated:YES completion:nil];
}

@end
