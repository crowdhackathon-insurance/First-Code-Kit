//
//  checkBoxesViewController.h
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 02/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface checkBoxesViewController : UIViewController

@end
