//
//  CarImagesViewController.h
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarImagesViewController : UIViewController <UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (weak, nonatomic) IBOutlet UIButton *topLeftButton;
@property (weak, nonatomic) IBOutlet UIButton *midLeftButton;
@property (weak, nonatomic) IBOutlet UIButton *botLeftButton;
@property (weak, nonatomic) IBOutlet UIButton *topRightButton;
@property (weak, nonatomic) IBOutlet UIButton *midRightButton;
@property (weak, nonatomic) IBOutlet UIButton *botRightButton;

@end
