//
//  StatementSelectionViewController.m
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 02/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import "StatementSelectionViewController.h"

@interface StatementSelectionViewController (){
    CLLocationManager *locationManager;
}

@end

@implementation StatementSelectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UINavigationBar *myBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
    UINavigationItem *navItem = [[UINavigationItem alloc] init];
    navItem.title = @"ΗΛΔΑ";
    
    myBar.items = @[ navItem ];
    
    [self.view addSubview:myBar];
    
    //background
    self.view.backgroundColor = [UIColor colorWithRed:141.0/255.0 green:198.0/255.0 blue:63.0/255.0 alpha:1];;
    
    //getLocation
    NSLog(@"getting location");
    [locationManager requestWhenInUseAuthorization];
    locationManager = [[CLLocationManager alloc]init]; // initializing locationManager

    
    //set locationButtonBackground
    [_getLocationButton setBackgroundImage:[UIImage imageNamed:@"x.png"] forState:UIControlStateNormal];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)submitButtonPressed:(id)sender {
}
- (IBAction)getLocationButtonPressed:(id)sender {
    NSLog(@"StartTakingLocationData:");
    
    locationManager.delegate = self; // we set the delegate of locationManager to self.
    locationManager.desiredAccuracy = kCLLocationAccuracyBest; // setting the accuracy
    
    [locationManager startUpdatingLocation];  //requesting location updates
    
    [_getLocationButton setBackgroundImage:nil forState:UIControlStateNormal];
    [_getLocationButton setBackgroundImage:[UIImage imageNamed:@"ok.png"] forState:UIControlStateNormal];

}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    
    if (currentLocation != nil) {
        
        //longitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        //latitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
    }
}


@end
