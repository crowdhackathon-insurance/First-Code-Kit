//
//  VerificationViewController.h
//  HackathonApp
//
//  Created by KECHAGIAS KONSTANTINOS on 01/10/2016.
//  Copyright © 2016 KECHAGIAS KONSTANTINOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VerificationViewController : UIViewController{
    NSTimer *timer;
    int secondsCount;
    IBOutlet UILabel *countDownLabel;
}
@property (weak, nonatomic) IBOutlet UITextField *verificationTextfield;
@property (weak, nonatomic) IBOutlet UILabel *verificationLabel;
@property (weak, nonatomic) IBOutlet UIButton *verificationButton;
@property (weak, nonatomic) IBOutlet UILabel *wrongCodeLabel;

@end
