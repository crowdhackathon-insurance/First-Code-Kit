package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Action" + request.getParameter("act"));
		System.out.println("Id1 " + request.getParameter("firstId"));
		System.out.println("Id2 " + request.getParameter("secondId"));
		System.out.println("Token " + request.getParameter("firstToken"));
		
		if((request.getParameter("act") != null) && request.getParameter("act").equals("findFraud")){  
			String USER_AGENT = "Mozilla/5.0";
			String url = "https://graph.facebook.com/v2.7/" + request.getParameter("firstId") + "/friends/" + request.getParameter("secondId") + "?access_token=" + request.getParameter("firstToken");

			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			con.setRequestProperty("User-Agent", USER_AGENT);

			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
					new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer stringResponse = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				stringResponse.append(inputLine);
			}
			in.close();

			//print result
			System.out.println(stringResponse.toString());
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}else if((request.getParameter("act") != null) && request.getParameter("act").equals("sendEmail")){  
			System.out.println("sendEmailTo " + request.getParameter("to"));
			//Recipient's email ID needs to be mentioned.
		    String to = request.getParameter("to");//change accordingly

		    // Sender's email ID needs to be mentioned
		    String from = "hdacrowdhackathon@gmail.com";//change accordingly
		    final String username = "hdacrowdhackathon@gmail.com";//change accordingly
		    final String password = "01102016";//change accordingly

		    // Assuming you are sending email through relay.jangosmtp.net
		    String host = "smtp.gmail.com";

		    Properties props = new Properties();
		    props.put("mail.smtp.auth", "true");
		    props.put("mail.smtp.starttls.enable", "true");
		    props.put("mail.smtp.host", host);
		    props.put("mail.smtp.port", "587");

		    // Get the Session object.
		    Session session = Session.getInstance(props,
		    		new javax.mail.Authenticator() {
		    			protected PasswordAuthentication getPasswordAuthentication() {
		    				return new PasswordAuthentication(username, password);
		    			}
		      	});

		    int VerificationCode= (int)(Math.random()*10000);
		    String Vcode= ""+VerificationCode;
		      
		    try {
		    	// Create a default MimeMessage object.
		        Message message = new MimeMessage(session);

		      
		        // Set From: header field of the header.
		        message.setFrom(new InternetAddress(from));

		        // Set To: header field of the header.
		        message.setRecipients(Message.RecipientType.TO,
		        InternetAddress.parse(to));

		        // Set Subject: header field
		        message.setSubject("Κωδικός επιβεβαίωσης");

		        // Now set the actual message
		        message.setText("Λυπούμαστε που είχατε ένα αυτοκινηστικό ατύχημα." +System.lineSeparator()+System.lineSeparator()
		           + "Ο κωδικός επιβεβαίωσης είναι ο :  "
		           + Vcode+System.lineSeparator() +System.lineSeparator()
		           + "Παρακαλούμε μείνετε ψύχραιμος και θα λυθεί φιλικά!"
		        );

		        // Send message
		        Transport.send(message);

		        System.out.println("Sent message successfully....");
				response.getWriter().append("Served at: ").append(request.getContextPath());

		    } catch (MessagingException e) {
		    	throw new RuntimeException(e);
		    }
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
